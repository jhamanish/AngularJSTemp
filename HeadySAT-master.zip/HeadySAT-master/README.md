# HeadySAT
This is an SAT for Heady Technologies.
This project was an attempt to make a small website with SPA feature along with the responsive UI.
1) SPA was accomplished using AngularJS 1.6.X
2) CSS Grids with media queries were used to create the responsive UI (desktop and mobile)

Thanks.

Ankit Anand
